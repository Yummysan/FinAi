# FinQuant — AI Research Dashboard (Indian Markets)
## Architecture Overview · SEBI 2026 Compliant

---

## Project Structure
```
lib/
├── core/
│   ├── compliance/
│   │   └── sebi_decision_log.dart     ← AES-256 encrypted audit log, 7-yr retention
│   ├── models/
│   │   └── research_models.dart       ← Typed JSON schemas (ResearchPlan, EvidenceLink, etc.)
│   ├── repositories/
│   │   └── execution_repository.dart  ← IExecutionRepository + MockPaperTrader + LiveBrokerTrader
│   └── services/
│       ├── llm_service.dart           ← Gemini API · CoT prompting · Judge Layer
│       ├── tax_engine.dart            ← 2026 Indian tax: Crypto / Equity / US-LRS
│       └── broker_deep_link.dart      ← Zerodha kite:// + Upstox OAuth deep links
├── features/research/
│   ├── bloc/
│   │   └── research_bloc.dart         ← BLoC orchestrator + Flutter Isolates (6 scrapers)
│   └── ui/
│       ├── dashboard_screen.dart      ← Main UI + SEBI disclaimer banner
│       ├── research_stepper.dart      ← "Machine is Working" animated stepper
│       ├── result_card.dart           ← Trade plan (editable) + Tax summary + Execute
│       └── data_sources_sheet.dart    ← Navigable bottom sheet · Evidence map
└── main.dart                          ← DI bootstrap + SEBI log init
```

---

## How Each Spec Maps to Code

### Flutter Architecture (Spec 1)
| Spec Requirement | Implementation |
|---|---|
| `IExecutionRepository` | `execution_repository.dart` — abstract class |
| `MockPaperTrader` | Same file — SQLite/local simulation |
| `LiveBrokerTrader` | Same file — Dio + Kite/Upstox API |
| UI never knows if real/paper | Both implement same interface |
| Flutter Isolates for 6 scrapers | `_scraperIsolateEntry` in `research_bloc.dart` |
| BLoC + ResearchStep events | `research_bloc.dart` — full event/state machine |
| "Machine is Working" stepper | `research_stepper.dart` — animated granular stepper |
| Data Sources bottom sheet | `data_sources_sheet.dart` — maps every field → source URL |
| Zerodha/Upstox deep links | `broker_deep_link.dart` |

### AI Quant (Spec 2)
| Spec Requirement | Implementation |
|---|---|
| Schema-first JSON (Zod equivalent) | `ResearchPlan.fromJson` with type assertions |
| Chain-of-Thought monologue | `_buildPrompt` forces `<thinking>` block before JSON |
| Evidence mapping | `evidence_links` array — every field must cite scraper+timestamp |
| Judge Layer (delta > 0.01% → fail) | `_judgeOutput` in `llm_service.dart` |
| Determinism check + retry | Up to 3 retries with `_maxRetries` |

### SEBI Compliance (Spec 3)
| Spec Requirement | Implementation |
|---|---|
| AI Decision Log (encrypted SQLite) | `sebi_decision_log.dart` — AES-256-GCM, Flutter Secure Storage key |
| Stores prompt + raw data + LLM output | All three fields encrypted separately |
| 7-year retention | `expires_at` column + `purgeExpired()` on startup |
| "Research Analysis Tool" UI labels | `_DisclaimerBanner` + card headers |
| Edit button (human final agency) | `_isEditing` toggle in `ResultCard` |
| Biometric before live trade | `local_auth` in `LiveBrokerTrader.placeOrder` |
| OAuth 2.0 for broker | Upstox OAuth URI flow in `broker_deep_link.dart` |

---

## Quick Start

### 1. Get dependencies
```bash
flutter pub get
flutter pub run build_runner build --delete-conflicting-outputs
```

### 2. Add your Gemini API key
In `LlmService.generateResearchPlan`, pass your key:
```dart
await _llmService.generateResearchPlan(
  ticker: 'ETH-INR',
  asset_type: 'crypto',
  scraped_data: data,
  api_key: 'YOUR_GEMINI_API_KEY', // or use flutter_secure_storage
);
```

### 3. Android permissions (add to AndroidManifest.xml)
```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.USE_BIOMETRIC" />
<uses-permission android:name="android.permission.USE_FINGERPRINT" />
```

### 4. Switch to live trading
In `main.dart`, replace `MockPaperTrader` with `LiveBrokerTrader`:
```dart
repository: LiveBrokerTrader(broker: 'zerodha'),
```
⚠️ **Live trading requires biometric confirmation — hardcoded per SEBI 2026 spec.**

---

## Next Steps (TODOs marked in code)
- [ ] Implement real HTTP scrapers in `_scraperIsolateEntry` (NSE, BSE, Moneycontrol, etc.)
- [ ] Add Zerodha Kite Connect OAuth 2.0 token refresh flow
- [ ] Add `fl_chart` price chart to `ResultCard`
- [ ] Implement SEBI audit export (CSV/encrypted zip) for compliance officer
- [ ] Add LRS remittance tracker for US stock investors
