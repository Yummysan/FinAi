// lib/features/research/bloc/research_bloc.dart
// Async Research Orchestrator — Flutter Isolates + BLoC

import 'dart:async';
import 'dart:isolate';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:uuid/uuid.dart';
import '../../../core/models/research_models.dart';
import '../../../core/services/llm_service.dart';
import '../../../core/services/tax_engine.dart';
import '../../../core/compliance/sebi_decision_log.dart';
import '../../../core/repositories/i_execution_repository.dart';
// ── Events ────────────────────────────────────────────────────────────────────
abstract class ResearchEvent extends Equatable {
  const ResearchEvent();
  @override
  List<Object?> get props => [];
}

class StartResearch extends ResearchEvent {
  final String ticker;
  final String asset_type;
  const StartResearch({required this.ticker, required this.asset_type});
  @override
  List<Object?> get props => [ticker, asset_type];
}

class StepUpdated extends ResearchEvent {
  final ResearchStep step;
  const StepUpdated(this.step);
  @override
  List<Object?> get props => [step];
}

class ResearchCompleted extends ResearchEvent {
  final ResearchPlan plan;
  final TaxCalculation tax;
  final String sebi_log_id;
  const ResearchCompleted({required this.plan, required this.tax, required this.sebi_log_id});
  @override
  List<Object?> get props => [plan.ticker];
}

class ResearchFailed extends ResearchEvent {
  final String error;
  const ResearchFailed(this.error);
  @override
  List<Object?> get props => [error];
}

class ConfirmAndExecute extends ResearchEvent {
  final ResearchPlan plan;
  final int quantity;
  const ConfirmAndExecute({required this.plan, required this.quantity});
  @override
  List<Object?> get props => [plan.ticker, quantity];
}

class ResetResearch extends ResearchEvent {
  const ResetResearch();
}

// ── States ────────────────────────────────────────────────────────────────────
abstract class ResearchState extends Equatable {
  const ResearchState();
  @override
  List<Object?> get props => [];
}

class ResearchIdle extends ResearchState {}

class ResearchRunning extends ResearchState {
  final List<ResearchStep> steps;
  const ResearchRunning({required this.steps});
  @override
  List<Object?> get props => [steps];
}

class ResearchReady extends ResearchState {
  final ResearchPlan plan;
  final TaxCalculation tax;
  final String sebi_log_id;
  final bool is_editable; // SEBI: user must retain final agency
  const ResearchReady({
    required this.plan,
    required this.tax,
    required this.sebi_log_id,
    this.is_editable = true,
  });
  @override
  List<Object?> get props => [plan.ticker, plan.generated_at];
}

class ResearchError extends ResearchState {
  final String message;
  const ResearchError(this.message);
  @override
  List<Object?> get props => [message];
}

class ExecutionPending extends ResearchState {
  final ResearchPlan plan;
  const ExecutionPending(this.plan);
  @override
  List<Object?> get props => [plan.ticker];
}

class ExecutionSuccess extends ResearchState {
  final String order_id;
  final bool is_paper;
  const ExecutionSuccess({required this.order_id, required this.is_paper});
  @override
  List<Object?> get props => [order_id];
}

// ── BLoC ──────────────────────────────────────────────────────────────────────
class ResearchBloc extends Bloc<ResearchEvent, ResearchState> {
  final LlmService _llmService;
  final SebiDecisionLog _sebiLog;
  final IExecutionRepository _repository;
  final _uuid = const Uuid();

  // 6 scraper step definitions
  static final List<ResearchStep> _initialSteps = [
    const ResearchStep(id: 'Scraper_1', label: 'Fetching NSE live feed', status: ResearchStepStatus.pending),
    const ResearchStep(id: 'Scraper_2', label: 'Fetching BSE order book', status: ResearchStepStatus.pending),
    const ResearchStep(id: 'Scraper_3', label: 'Fetching F&O OI data', status: ResearchStepStatus.pending),
    const ResearchStep(id: 'Scraper_4', label: 'Fetching Moneycontrol fundamentals', status: ResearchStepStatus.pending),
    const ResearchStep(id: 'Scraper_5', label: 'Fetching global indices', status: ResearchStepStatus.pending),
    const ResearchStep(id: 'Scraper_6', label: 'Fetching sentiment / news', status: ResearchStepStatus.pending),
    const ResearchStep(id: 'LLM_Processing', label: 'AI Quant analysis (CoT + Judge)', status: ResearchStepStatus.pending),
    const ResearchStep(id: 'Tax_Calc', label: 'Calculating 2026 net profit', status: ResearchStepStatus.pending),
    const ResearchStep(id: 'SEBI_Log', label: 'Encrypting SEBI audit log', status: ResearchStepStatus.pending),
  ];

  ResearchBloc({
    required LlmService llmService,
    required SebiDecisionLog sebiLog,
    required IExecutionRepository repository,
  })  : _llmService = llmService,
        _sebiLog = sebiLog,
        _repository = repository,
        super(ResearchIdle()) {
    on<StartResearch>(_onStartResearch);
    on<StepUpdated>(_onStepUpdated);
    on<ResearchCompleted>(_onResearchCompleted);
    on<ResearchFailed>(_onResearchFailed);
    on<ConfirmAndExecute>(_onConfirmAndExecute);
    on<ResetResearch>((_, emit) => emit(ResearchIdle()));
  }

  // ── Start Research ────────────────────────────────────────────────────────
  Future<void> _onStartResearch(
      StartResearch event,
      Emitter<ResearchState> emit,
      ) async {
    final steps = List<ResearchStep>.from(_initialSteps);
    emit(ResearchRunning(steps: steps));

    // Run 6 scrapers in parallel Isolates
    final receivePort = ReceivePort();
    await Isolate.spawn(
      _scraperIsolateEntry,
      _ScraperPayload(
        sendPort: receivePort.sendPort,
        ticker: event.ticker,
        asset_type: event.asset_type,
      ),
    );

    // Listen to Isolate events and relay as BLoC events
    await for (final message in receivePort) {
      if (message is _StepUpdate) {
        add(StepUpdated(message.step));
      } else if (message is _ScraperResult) {
        receivePort.close();
        // Now call LLM in main isolate (Dio doesn't work in spawned isolates)
        await _runLlmAndFinalize(event, message.scraped_data, emit);
        break;
      } else if (message is String && message == 'ERROR') {
        receivePort.close();
        add(const ResearchFailed('Scraper pipeline failed'));
        break;
      }
    }
  }

  Future<void> _runLlmAndFinalize(
      StartResearch event,
      List<RawScraperData> scraped_data,
      Emitter<ResearchState> emit,
      ) async {
    // Update LLM step → running
    _updateStep(emit, 'LLM_Processing', ResearchStepStatus.running);

    try {
      final result = await _llmService.generateResearchPlan(
        ticker: event.ticker,
        asset_type: event.asset_type,
        scraped_data: scraped_data,
      );

      _updateStep(emit, 'LLM_Processing', ResearchStepStatus.complete);

      // Tax calculation
      _updateStep(emit, 'Tax_Calc', ResearchStepStatus.running);
      final tax = _computeTax(result.plan);
      _updateStep(emit, 'Tax_Calc', ResearchStepStatus.complete);

      // SEBI log
      _updateStep(emit, 'SEBI_Log', ResearchStepStatus.running);
      final logId = await _sebiLog.logDecision(
        id: _uuid.v4(),
        prompt: result.prompt_used,
        raw_scraper_data: {
          for (final s in scraped_data) s.scraper_id: s.raw_fields
        },
        llm_output: result.plan,
        tax_formula_trace: tax.formula_trace,
      );
      _updateStep(emit, 'SEBI_Log', ResearchStepStatus.complete);

      add(ResearchCompleted(plan: result.plan, tax: tax, sebi_log_id: logId));
    } catch (e) {
      _updateStep(emit, 'LLM_Processing', ResearchStepStatus.failed, detail: e.toString());
      add(ResearchFailed(e.toString()));
    }
  }

  void _updateStep(
      Emitter<ResearchState> emit,
      String stepId,
      ResearchStepStatus status, {
        String? detail,
      }) {
    if (state is! ResearchRunning) return;
    final current = (state as ResearchRunning).steps;
    final updated = current
        .map((s) => s.id == stepId ? s.copyWith(status: status, detail: detail) : s)
        .toList();
    emit(ResearchRunning(steps: updated));
  }

  TaxCalculation _computeTax(ResearchPlan plan) {
    if (plan.asset_type == 'crypto') {
      return IndianTaxEngine.calculateCrypto(
        gains: plan.plan.entry * 0.05, // placeholder gain for display
        total_transaction_value: plan.plan.entry,
      );
    } else if (plan.asset_type == 'us_equity') {
      return IndianTaxEngine.calculateUSEquity(
        gains: plan.plan.entry * 0.05,
        remittance_amount: plan.plan.entry,
        is_long_term: false,
      );
    } else {
      return IndianTaxEngine.calculateEquity(
        sell_value: plan.plan.entry,
        gains: plan.plan.entry * 0.05,
        is_intraday: false,
        is_long_term: false,
        brokerage: 20.0,
      );
    }
  }

  void _onStepUpdated(StepUpdated event, Emitter<ResearchState> emit) {
    if (state is! ResearchRunning) return;
    final current = (state as ResearchRunning).steps;
    final updated = current
        .map((s) => s.id == event.step.id ? event.step : s)
        .toList();
    emit(ResearchRunning(steps: updated));
  }

  void _onResearchCompleted(ResearchCompleted event, Emitter<ResearchState> emit) {
    emit(ResearchReady(
      plan: event.plan,
      tax: event.tax,
      sebi_log_id: event.sebi_log_id,
    ));
  }

  void _onResearchFailed(ResearchFailed event, Emitter<ResearchState> emit) {
    emit(ResearchError(event.error));
  }

  Future<void> _onConfirmAndExecute(
      ConfirmAndExecute event,
      Emitter<ResearchState> emit,
      ) async {
    emit(ExecutionPending(event.plan));
    try {
      final orderId = await _repository.placeOrder(
        plan: event.plan,
        quantity: event.quantity,
        requireBiometricConfirm: _repository.isLive,
      );
      emit(ExecutionSuccess(order_id: orderId, is_paper: !_repository.isLive));
    } catch (e) {
      emit(ResearchError('Execution failed: $e'));
    }
  }
}

// ── Isolate Plumbing ──────────────────────────────────────────────────────────
class _ScraperPayload {
  final SendPort sendPort;
  final String ticker;
  final String asset_type;
  const _ScraperPayload({
    required this.sendPort,
    required this.ticker,
    required this.asset_type,
  });
}

class _StepUpdate {
  final ResearchStep step;
  const _StepUpdate(this.step);
}

class _ScraperResult {
  final List<RawScraperData> scraped_data;
  const _ScraperResult(this.scraped_data);
}

/// Runs in a separate Isolate — no Flutter/UI code, pure Dart.
void _scraperIsolateEntry(_ScraperPayload payload) async {
  final scraperIds = [
    'Scraper_1', 'Scraper_2', 'Scraper_3',
    'Scraper_4', 'Scraper_5', 'Scraper_6',
  ];

  final List<RawScraperData> results = [];

  // Run scrapers concurrently
  await Future.wait(scraperIds.map((id) async {
    // Notify: running
    payload.sendPort.send(_StepUpdate(ResearchStep(
      id: id,
      label: id,
      status: ResearchStepStatus.running,
    )));

    // TODO: Replace with real HTTP scraper per source
    await Future.delayed(const Duration(milliseconds: 800));

    // Mock raw data — replace with actual scraper output
    final mockData = RawScraperData(
      scraper_id: id,
      ticker: payload.ticker,
      raw_fields: {
        'ltp': 320100.0,
        'pe': 24.9,
        'volume': 1234567,
        'oi': 89000,
      },
      scraped_at: DateTime.now(),
    );
    results.add(mockData);

    // Notify: complete
    payload.sendPort.send(_StepUpdate(ResearchStep(
      id: id,
      label: id,
      status: ResearchStepStatus.complete,
    )));
  }));

  payload.sendPort.send(_ScraperResult(results));
}