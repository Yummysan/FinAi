// lib/features/research/ui/dashboard_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../core/theme/app_theme.dart';
import '../bloc/research_bloc_fixed.dart';
import 'research_stepper.dart';
import 'data_sources_sheet.dart';
import 'result_card.dart';
import 'broker_connect_screen.dart';
import 'settings_screen.dart';

const Map<String, List<String>> _tickerMap = {
  'crypto':    ['BTC-INR','ETH-INR','SOL-INR','XRP-INR','BNB-INR','ADA-INR','DOGE-INR','MATIC-INR','DOT-INR','AVAX-INR'],
  'equity':    ['RELIANCE','TCS','INFY','HDFCBANK','ICICIBANK','WIPRO','SBIN','BAJFINANCE','HINDUNILVR','KOTAKBANK'],
  'us_equity': ['AAPL','MSFT','GOOGL','AMZN','NVDA','TSLA','META','NFLX','AMD','ORCL'],
};

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  String _assetType = 'crypto';
  String? _ticker;
  bool _isLiveMode = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: FinAITheme.bg,
      body: SafeArea(
        child: Column(children: [
          _TopBar(
            isLive: _isLiveMode,
            onToggleMode: () => setState(() => _isLiveMode = !_isLiveMode),
            onSettings: () => Navigator.push(context, _slide(const SettingsScreen())),
            onConnect: () => Navigator.push(context, _slide(const BrokerConnectScreen())),
          ),
          const _SebiStrip(),
          Expanded(
            child: BlocConsumer<ResearchBloc, ResearchState>(
              listener: (context, state) {
                if (state is ExecutionSuccess) {
                  _showSnack(context, state.is_paper
                      ? '📄 Paper order placed — ${state.order_id.substring(0, 8)}'
                      : '✅ Live order placed — ${state.order_id}');
                }
              },
              builder: (context, state) {
                if (state is ResearchIdle) {
                  return _HomePanel(
                    assetType: _assetType,
                    ticker: _ticker,
                    isLive: _isLiveMode,
                    onAssetType: (v) => setState(() { _assetType = v; _ticker = null; }),
                    onTicker: (v) => setState(() => _ticker = v),
                    onRun: () {
                      if (_ticker == null) {
                        _showSnack(context, 'Select a ticker first');
                        return;
                      }
                      context.read<ResearchBloc>().add(
                        StartResearch(ticker: _ticker!, asset_type: _assetType),
                      );
                    },
                  );
                }
                if (state is ResearchRunning) {
                  return ResearchStepperWidget(steps: state.steps);
                }
                if (state is ResearchReady) {
                  return ResultCard(
                    plan: state.plan,
                    tax: state.tax,
                    sebiLogId: state.sebi_log_id,
                    onShowSources: () => showModalBottomSheet(
                      context: context,
                      isScrollControlled: true,
                      backgroundColor: Colors.transparent,
                      builder: (_) => DataSourcesSheet(plan: state.plan),
                    ),
                    onExecute: (qty) => context.read<ResearchBloc>().add(
                      ConfirmAndExecute(plan: state.plan, quantity: qty),
                    ),
                    onNewResearch: () => context.read<ResearchBloc>().add(
                      const ResetResearch(),
                    ),
                  );
                }
                if (state is ResearchError) {
                  return _ErrorPanel(message: state.message);
                }
                if (state is ExecutionPending) {
                  return _LoadingPanel(label: _isLiveMode ? 'Awaiting biometric…' : 'Placing paper order…');
                }
                if (state is ExecutionSuccess) {
                  return _LoadingPanel(label: 'Order placed!');
                }
                return const SizedBox.shrink();
              },
            ),
          ),
        ]),
      ),
    );
  }

  void _showSnack(BuildContext context, String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: FinAITheme.surface,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
        side: const BorderSide(color: FinAITheme.border),
      ),
      content: Text(msg, style: GoogleFonts.robotoMono(fontSize: 12, color: FinAITheme.textPrimary)),
    ));
  }

  Route _slide(Widget page) => PageRouteBuilder(
    pageBuilder: (_, __, ___) => page,
    transitionsBuilder: (_, anim, __, child) => SlideTransition(
      position: Tween(begin: const Offset(1, 0), end: Offset.zero)
          .animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
      child: child,
    ),
  );
}

// ── Top Bar ───────────────────────────────────────────────────────────────────
class _TopBar extends StatelessWidget {
  final bool isLive;
  final VoidCallback onToggleMode, onSettings, onConnect;
  const _TopBar({
    required this.isLive,
    required this.onToggleMode,
    required this.onSettings,
    required this.onConnect,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: FinAITheme.border, width: 0.5)),
      ),
      child: Row(children: [
        RichText(text: TextSpan(children: [
          TextSpan(text: 'Fin', style: GoogleFonts.syne(fontSize: 22, fontWeight: FontWeight.w800, color: FinAITheme.accentBlue)),
          TextSpan(text: 'AI', style: GoogleFonts.syne(fontSize: 22, fontWeight: FontWeight.w300, color: FinAITheme.textPrimary)),
        ])),
        const SizedBox(width: 10),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
          decoration: BoxDecoration(
            color: FinAITheme.accentBlue.withOpacity(0.15),
            borderRadius: BorderRadius.circular(4),
          ),
          child: Text('BETA', style: GoogleFonts.robotoMono(fontSize: 9, color: FinAITheme.accentLight, letterSpacing: 1)),
        ),
        const Spacer(),
        GestureDetector(
          onTap: onToggleMode,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: isLive ? FinAITheme.bullGreen.withOpacity(0.12) : FinAITheme.surface,
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: isLive ? FinAITheme.bullGreen.withOpacity(0.5) : FinAITheme.border),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                width: 6, height: 6,
                decoration: BoxDecoration(
                  color: isLive ? FinAITheme.bullGreen : FinAITheme.textMuted,
                  shape: BoxShape.circle,
                  boxShadow: isLive
                      ? [BoxShadow(color: FinAITheme.bullGreen.withOpacity(0.7), blurRadius: 6)]
                      : null,
                ),
              ),
              const SizedBox(width: 6),
              Text(
                isLive ? 'LIVE' : 'PAPER',
                style: GoogleFonts.robotoMono(
                  fontSize: 10,
                  color: isLive ? FinAITheme.bullGreen : FinAITheme.textSecond,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1,
                ),
              ),
            ]),
          ),
        ),
        const SizedBox(width: 8),
        _IconBtn(icon: Icons.account_balance_outlined, onTap: onConnect),
        const SizedBox(width: 6),
        _IconBtn(icon: Icons.tune_rounded, onTap: onSettings),
      ]),
    );
  }
}

class _IconBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _IconBtn({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      width: 34, height: 34,
      decoration: BoxDecoration(
        color: FinAITheme.surface,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: FinAITheme.border),
      ),
      child: Icon(icon, size: 16, color: FinAITheme.textSecond),
    ),
  );
}

// ── SEBI Strip ────────────────────────────────────────────────────────────────
class _SebiStrip extends StatelessWidget {
  const _SebiStrip();
  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity,
    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
    color: const Color(0xFF050A14),
    child: Text(
      'RESEARCH ANALYSIS TOOL · NOT INVESTMENT ADVICE · FOR INFORMATIONAL USE ONLY',
      style: GoogleFonts.robotoMono(fontSize: 9, color: FinAITheme.textMuted, letterSpacing: 0.8),
    ),
  );
}

// ── Home Panel ────────────────────────────────────────────────────────────────
class _HomePanel extends StatefulWidget {
  final String assetType;
  final String? ticker;
  final bool isLive;
  final ValueChanged<String> onAssetType;
  final ValueChanged<String?> onTicker;
  final VoidCallback onRun;

  const _HomePanel({
    required this.assetType,
    required this.ticker,
    required this.isLive,
    required this.onAssetType,
    required this.onTicker,
    required this.onRun,
  });

  @override
  State<_HomePanel> createState() => _HomePanelState();
}

class _HomePanelState extends State<_HomePanel> {
  final _searchCtrl = TextEditingController();
  bool _dropdownOpen = false;
  List<String> _filtered = [];

  @override
  void initState() {
    super.initState();
    _filtered = _tickerMap[widget.assetType] ?? [];
  }

  void _filter(String q) {
    final list = _tickerMap[widget.assetType] ?? [];
    setState(() => _filtered = q.isEmpty
        ? list
        : list.where((t) => t.toLowerCase().contains(q.toLowerCase())).toList());
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const SizedBox(height: 8),
        Row(children: [
          _StatPill(label: 'NSE', value: 'OPEN', color: FinAITheme.bullGreen),
          const SizedBox(width: 8),
          _StatPill(label: 'BSE', value: 'OPEN', color: FinAITheme.bullGreen),
          const SizedBox(width: 8),
          _StatPill(label: 'CRYPTO', value: '24/7', color: FinAITheme.accentLight),
        ]),
        const SizedBox(height: 28),
        Text('ASSET CLASS', style: FinAITheme.label(10, FinAITheme.textMuted)),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: _AssetTab(
            label: 'CRYPTO', icon: Icons.currency_bitcoin, value: 'crypto',
            selected: widget.assetType,
            onTap: (v) { widget.onAssetType(v); setState(() { _filtered = _tickerMap[v] ?? []; _searchCtrl.clear(); }); },
          )),
          const SizedBox(width: 8),
          Expanded(child: _AssetTab(
            label: 'EQUITY', icon: Icons.show_chart, value: 'equity',
            selected: widget.assetType,
            onTap: (v) { widget.onAssetType(v); setState(() { _filtered = _tickerMap[v] ?? []; _searchCtrl.clear(); }); },
          )),
          const SizedBox(width: 8),
          Expanded(child: _AssetTab(
            label: 'US STOCK', icon: Icons.flag_outlined, value: 'us_equity',
            selected: widget.assetType,
            onTap: (v) { widget.onAssetType(v); setState(() { _filtered = _tickerMap[v] ?? []; _searchCtrl.clear(); }); },
          )),
        ]),
        const SizedBox(height: 28),
        Text('SELECT INSTRUMENT', style: FinAITheme.label(10, FinAITheme.textMuted)),
        const SizedBox(height: 10),
        Column(children: [
          GestureDetector(
            onTap: () => setState(() => _dropdownOpen = !_dropdownOpen),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: BoxDecoration(
                color: FinAITheme.surface,
                borderRadius: _dropdownOpen
                    ? const BorderRadius.vertical(top: Radius.circular(10))
                    : BorderRadius.circular(10),
                border: Border.all(
                  color: _dropdownOpen ? FinAITheme.accentBlue.withOpacity(0.5) : FinAITheme.border,
                ),
              ),
              child: Row(children: [
                Icon(Icons.search, size: 16, color: FinAITheme.textMuted),
                const SizedBox(width: 10),
                Expanded(
                  child: _dropdownOpen
                      ? TextField(
                    controller: _searchCtrl,
                    autofocus: true,
                    onChanged: _filter,
                    style: GoogleFonts.robotoMono(fontSize: 14, color: FinAITheme.textPrimary),
                    decoration: InputDecoration.collapsed(
                      hintText: 'Search ticker…',
                      hintStyle: GoogleFonts.robotoMono(fontSize: 14, color: FinAITheme.textMuted),
                    ),
                  )
                      : Text(
                    widget.ticker ?? 'Search ticker…',
                    style: GoogleFonts.robotoMono(
                      fontSize: 14,
                      color: widget.ticker != null ? FinAITheme.textPrimary : FinAITheme.textMuted,
                      fontWeight: widget.ticker != null ? FontWeight.w700 : FontWeight.normal,
                    ),
                  ),
                ),
                Icon(
                  _dropdownOpen ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down,
                  size: 18, color: FinAITheme.textMuted,
                ),
              ]),
            ),
          ),
          if (_dropdownOpen)
            Container(
              constraints: const BoxConstraints(maxHeight: 200),
              decoration: BoxDecoration(
                color: FinAITheme.bgSecondary,
                borderRadius: const BorderRadius.vertical(bottom: Radius.circular(10)),
                border: Border.all(color: FinAITheme.accentBlue.withOpacity(0.5)),
              ),
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: _filtered.length,
                itemBuilder: (_, i) {
                  final t = _filtered[i];
                  final isSelected = t == widget.ticker;
                  return GestureDetector(
                    onTap: () {
                      widget.onTicker(t);
                      setState(() {
                        _dropdownOpen = false;
                        _searchCtrl.clear();
                        _filtered = _tickerMap[widget.assetType] ?? [];
                      });
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        color: isSelected ? FinAITheme.accentBlue.withOpacity(0.1) : Colors.transparent,
                        border: Border(bottom: BorderSide(color: FinAITheme.border.withOpacity(0.5))),
                      ),
                      child: Row(children: [
                        Text(t, style: GoogleFonts.robotoMono(
                          fontSize: 13,
                          color: isSelected ? FinAITheme.accentLight : FinAITheme.textPrimary,
                          fontWeight: isSelected ? FontWeight.w700 : FontWeight.normal,
                        )),
                        if (isSelected) ...[
                          const Spacer(),
                          Icon(Icons.check, size: 14, color: FinAITheme.accentBlue),
                        ],
                      ]),
                    ),
                  );
                },
              ),
            ),
        ]),
        const SizedBox(height: 32),
        GestureDetector(
          onTap: widget.onRun,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 17),
            decoration: widget.ticker != null
                ? FinAITheme.glowButton()
                : BoxDecoration(
              color: FinAITheme.surface,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: FinAITheme.border),
            ),
            child: Center(child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.auto_graph_rounded, size: 16,
                  color: widget.ticker != null ? Colors.white : FinAITheme.textMuted),
              const SizedBox(width: 10),
              Text('RUN RESEARCH ANALYSIS',
                  style: GoogleFonts.syne(
                    fontSize: 13, fontWeight: FontWeight.w700,
                    color: widget.ticker != null ? Colors.white : FinAITheme.textMuted,
                    letterSpacing: 1.5,
                  )),
            ])),
          ),
        ),
        if (widget.isLive) ...[
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: FinAITheme.bearRed.withOpacity(0.08),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: FinAITheme.bearRed.withOpacity(0.3)),
            ),
            child: Row(children: [
              Icon(Icons.warning_amber_rounded, size: 14, color: FinAITheme.bearRed),
              const SizedBox(width: 8),
              Expanded(child: Text(
                'LIVE MODE: Real money. Biometric required before execution.',
                style: GoogleFonts.robotoMono(fontSize: 10, color: FinAITheme.bearRed),
              )),
            ]),
          ),
        ],
      ]),
    );
  }
}

class _StatPill extends StatelessWidget {
  final String label, value;
  final Color color;
  const _StatPill({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
    decoration: BoxDecoration(
      color: color.withOpacity(0.08),
      borderRadius: BorderRadius.circular(5),
      border: Border.all(color: color.withOpacity(0.25)),
    ),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Text(label, style: GoogleFonts.robotoMono(fontSize: 9, color: FinAITheme.textMuted, letterSpacing: 1)),
      const SizedBox(width: 6),
      Text(value, style: GoogleFonts.robotoMono(fontSize: 9, color: color, fontWeight: FontWeight.w700, letterSpacing: 1)),
    ]),
  );
}

class _AssetTab extends StatelessWidget {
  final String label, value, selected;
  final IconData icon;
  final ValueChanged<String> onTap;
  const _AssetTab({
    required this.label, required this.value, required this.selected,
    required this.icon, required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isSelected = value == selected;
    return GestureDetector(
      onTap: () => onTap(value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: isSelected ? FinAITheme.accentBlue.withOpacity(0.12) : FinAITheme.surface,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: isSelected ? FinAITheme.accentBlue.withOpacity(0.5) : FinAITheme.border),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 18, color: isSelected ? FinAITheme.accentBlue : FinAITheme.textMuted),
          const SizedBox(height: 5),
          Text(label, style: GoogleFonts.robotoMono(
            fontSize: 9,
            color: isSelected ? FinAITheme.accentLight : FinAITheme.textMuted,
            fontWeight: isSelected ? FontWeight.w700 : FontWeight.normal,
            letterSpacing: 1,
          )),
        ]),
      ),
    );
  }
}

class _ErrorPanel extends StatelessWidget {
  final String message;
  const _ErrorPanel({required this.message});

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.all(24),
    child: Center(
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: FinAITheme.bearRed.withOpacity(0.08),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: FinAITheme.bearRed.withOpacity(0.3)),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.error_outline_rounded, color: FinAITheme.bearRed, size: 40),
          const SizedBox(height: 12),
          Text('Research Failed', style: GoogleFonts.syne(fontSize: 18, color: FinAITheme.bearRed, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          Text(message, style: GoogleFonts.robotoMono(fontSize: 11, color: FinAITheme.textSecond), textAlign: TextAlign.center),
          const SizedBox(height: 12),
          Text('Set your Gemini API key in Settings ⚙️',
              style: GoogleFonts.robotoMono(fontSize: 10, color: FinAITheme.textMuted), textAlign: TextAlign.center),
        ]),
      ),
    ),
  );
}

class _LoadingPanel extends StatelessWidget {
  final String label;
  const _LoadingPanel({required this.label});

  @override
  Widget build(BuildContext context) => Center(
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      SizedBox(width: 32, height: 32,
          child: CircularProgressIndicator(strokeWidth: 2, color: FinAITheme.accentBlue)),
      const SizedBox(height: 16),
      Text(label, style: GoogleFonts.robotoMono(fontSize: 12, color: FinAITheme.textSecond)),
    ]),
  );
}