// lib/features/research/ui/result_card.dart

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../core/models/research_models.dart';
import '../../../core/services/tax_engine.dart';
import '../../../core/theme/app_theme.dart';

class ResultCard extends StatefulWidget {
  final ResearchPlan plan;
  final TaxCalculation tax;
  final String sebiLogId;
  final VoidCallback onShowSources;
  final Function(int qty) onExecute;
  final VoidCallback onNewResearch;

  const ResultCard({super.key, required this.plan, required this.tax, required this.sebiLogId, required this.onShowSources, required this.onExecute, required this.onNewResearch});

  @override
  State<ResultCard> createState() => _ResultCardState();
}

class _ResultCardState extends State<ResultCard> {
  late double _entry, _stopLoss, _target;
  final _qtyCtrl = TextEditingController(text: '1');
  bool _isEditing = false;

  @override
  void initState() {
    super.initState();
    _entry = widget.plan.plan.entry;
    _stopLoss = widget.plan.plan.stop_loss;
    _target = widget.plan.plan.target ?? 0.0;
  }

  double get _riskReward => _target > 0 && _entry > 0 && _stopLoss > 0
    ? (_target - _entry) / (_entry - _stopLoss) : 0;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // ── Ticker header ──────────────────────────────────────────────────
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('RESEARCH ANALYSIS TOOL', style: FinAITheme.label(9, FinAITheme.textMuted)),
            const SizedBox(height: 4),
            Text(widget.plan.ticker, style: GoogleFonts.syne(fontSize: 30, color: FinAITheme.textPrimary, fontWeight: FontWeight.w800)),
            Text(widget.plan.asset_type.toUpperCase().replaceAll('_', ' '),
              style: GoogleFonts.robotoMono(fontSize: 10, color: FinAITheme.accentLight, letterSpacing: 1)),
          ])),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            _ConfidenceBadge(confidence: widget.plan.confidence),
            const SizedBox(height: 6),
            if (_riskReward > 0)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(color: FinAITheme.surface, borderRadius: BorderRadius.circular(5), border: Border.all(color: FinAITheme.border)),
                child: Text('R:R  ${_riskReward.toStringAsFixed(2)}',
                  style: GoogleFonts.robotoMono(fontSize: 10, color: FinAITheme.textSecond)),
              ),
          ]),
        ]),
        const SizedBox(height: 20),

        // ── Trade Plan ─────────────────────────────────────────────────────
        Container(
          decoration: FinAITheme.card(),
          child: Column(children: [
            // Header
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
              child: Row(children: [
                Text('TRADE PLAN', style: FinAITheme.label(10, FinAITheme.textMuted)),
                const Spacer(),
                GestureDetector(
                  onTap: () => setState(() => _isEditing = !_isEditing),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: _isEditing ? FinAITheme.accentBlue.withOpacity(0.12) : Colors.transparent,
                      borderRadius: BorderRadius.circular(5),
                      border: Border.all(color: FinAITheme.accentBlue.withOpacity(0.4)),
                    ),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(_isEditing ? Icons.check_rounded : Icons.edit_outlined, size: 12, color: FinAITheme.accentBlue),
                      const SizedBox(width: 4),
                      Text(_isEditing ? 'DONE' : 'EDIT', style: GoogleFonts.robotoMono(fontSize: 9, color: FinAITheme.accentBlue, letterSpacing: 1)),
                    ]),
                  ),
                ),
              ]),
            ),
            const SizedBox(height: 12),
            // Price levels
            _PriceRow(label: 'ENTRY', value: _entry, isEditing: _isEditing, color: FinAITheme.textPrimary, onChanged: (v) => setState(() => _entry = v)),
            _Divider(),
            _PriceRow(label: 'STOP LOSS', value: _stopLoss, isEditing: _isEditing, color: FinAITheme.bearRed, onChanged: (v) => setState(() => _stopLoss = v)),
            _Divider(),
            _PriceRow(label: 'TARGET', value: _target, isEditing: _isEditing, color: FinAITheme.bullGreen, onChanged: (v) => setState(() => _target = v)),
            _Divider(),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
              child: Row(children: [
                Text('POSITION SIZE', style: FinAITheme.label(9, FinAITheme.textMuted)),
                const Spacer(),
                Text('${(widget.plan.plan.split * 100).toStringAsFixed(0)}% of capital',
                  style: GoogleFonts.robotoMono(fontSize: 12, color: FinAITheme.textSecond)),
              ]),
            ),
          ]),
        ),
        const SizedBox(height: 12),

        // ── Tax Projection ─────────────────────────────────────────────────
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: FinAITheme.bullGreen.withOpacity(0.05),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: FinAITheme.bullGreen.withOpacity(0.15)),
          ),
          child: Row(children: [
            Icon(Icons.receipt_long_outlined, size: 16, color: FinAITheme.bullGreen.withOpacity(0.7)),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('2026 TAX PROJECTION', style: FinAITheme.label(9, FinAITheme.bullGreen.withOpacity(0.7))),
              const SizedBox(height: 3),
              Text(widget.tax.formula_trace, style: GoogleFonts.robotoMono(fontSize: 9, color: FinAITheme.textSecond)),
            ])),
            Text('₹${widget.tax.net_profit.toStringAsFixed(0)}',
              style: GoogleFonts.robotoMono(fontSize: 15, color: FinAITheme.bullGreen, fontWeight: FontWeight.w700)),
          ]),
        ),
        const SizedBox(height: 12),

        // ── SEBI Log / Sources ─────────────────────────────────────────────
        GestureDetector(
          onTap: widget.onShowSources,
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: FinAITheme.card(),
            child: Row(children: [
              Icon(Icons.shield_outlined, size: 15, color: FinAITheme.accentLight),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('SEBI AI Audit Log', style: GoogleFonts.robotoMono(fontSize: 11, color: FinAITheme.textPrimary)),
                Text('AES-256 · 7yr retention · ${widget.sebiLogId.substring(0, 8)}…',
                  style: GoogleFonts.robotoMono(fontSize: 9, color: FinAITheme.textMuted)),
              ])),
              Text('${widget.plan.sources.length} sources', style: GoogleFonts.robotoMono(fontSize: 10, color: FinAITheme.accentLight)),
              const SizedBox(width: 4),
              Icon(Icons.chevron_right_rounded, size: 14, color: FinAITheme.textMuted),
            ]),
          ),
        ),
        const SizedBox(height: 20),

        // ── Execute ────────────────────────────────────────────────────────
        Row(children: [
          Container(
            width: 72,
            decoration: FinAITheme.card(),
            child: TextField(
              controller: _qtyCtrl,
              keyboardType: TextInputType.number,
              textAlign: TextAlign.center,
              style: GoogleFonts.robotoMono(fontSize: 16, color: FinAITheme.textPrimary, fontWeight: FontWeight.w700),
              decoration: InputDecoration(
                hintText: 'QTY',
                hintStyle: GoogleFonts.robotoMono(fontSize: 11, color: FinAITheme.textMuted),
                contentPadding: const EdgeInsets.symmetric(vertical: 14),
                border: InputBorder.none,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: GestureDetector(
              onTap: () => widget.onExecute(int.tryParse(_qtyCtrl.text) ?? 1),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 15),
                decoration: FinAITheme.glowButton(),
                child: Center(child: Text('CONFIRM & EXECUTE',
                  style: GoogleFonts.syne(fontSize: 13, fontWeight: FontWeight.w700, color: Colors.white, letterSpacing: 1.5))),
              ),
            ),
          ),
        ]),
        const SizedBox(height: 12),
        GestureDetector(
          onTap: widget.onNewResearch,
          child: Center(child: Text('← New Research',
            style: GoogleFonts.robotoMono(fontSize: 12, color: FinAITheme.textSecond, decoration: TextDecoration.underline, decorationColor: FinAITheme.textSecond))),
        ),
        const SizedBox(height: 8),
      ]),
    );
  }
}

class _Divider extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Container(height: 0.5, color: FinAITheme.border, margin: const EdgeInsets.symmetric(horizontal: 16));
}

class _PriceRow extends StatelessWidget {
  final String label;
  final double value;
  final bool isEditing;
  final Color color;
  final ValueChanged<double> onChanged;
  const _PriceRow({required this.label, required this.value, required this.isEditing, required this.color, required this.onChanged});

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
    child: Row(children: [
      Text(label, style: FinAITheme.label(9, FinAITheme.textMuted)),
      const Spacer(),
      isEditing
        ? SizedBox(width: 110,
            child: TextField(
              controller: TextEditingController(text: value.toStringAsFixed(2)),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              textAlign: TextAlign.right,
              style: GoogleFonts.robotoMono(fontSize: 16, color: color, fontWeight: FontWeight.w700),
              decoration: InputDecoration(
                prefixText: '₹',
                prefixStyle: GoogleFonts.robotoMono(color: FinAITheme.textMuted, fontSize: 12),
                contentPadding: EdgeInsets.zero,
                border: UnderlineInputBorder(borderSide: BorderSide(color: color.withOpacity(0.5))),
                focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: color)),
              ),
              onChanged: (v) => onChanged(double.tryParse(v) ?? value),
            ))
        : Text('₹${value.toStringAsFixed(2)}',
            style: GoogleFonts.robotoMono(fontSize: 17, color: color, fontWeight: FontWeight.w700)),
    ]),
  );
}

class _ConfidenceBadge extends StatelessWidget {
  final double confidence;
  const _ConfidenceBadge({required this.confidence});
  @override
  Widget build(BuildContext context) {
    final color = confidence >= 0.75 ? FinAITheme.bullGreen : confidence >= 0.5 ? FinAITheme.warningAmber : FinAITheme.bearRed;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: color.withOpacity(0.35)),
      ),
      child: Text('${(confidence * 100).toStringAsFixed(0)}% CONF',
        style: GoogleFonts.robotoMono(fontSize: 11, color: color, fontWeight: FontWeight.w700, letterSpacing: 0.5)),
    );
  }
}
