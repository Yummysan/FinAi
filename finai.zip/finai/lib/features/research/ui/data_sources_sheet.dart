// lib/features/research/ui/data_sources_sheet.dart

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../core/models/research_models.dart';
import '../../../core/theme/app_theme.dart';

class DataSourcesSheet extends StatelessWidget {
  final ResearchPlan plan;
  const DataSourcesSheet({super.key, required this.plan});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: FinAITheme.bgSecondary,
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Center(child: Container(width: 36, height: 3, decoration: BoxDecoration(color: FinAITheme.border, borderRadius: BorderRadius.circular(2)))),
        const SizedBox(height: 18),
        Row(children: [
          Text('DATA SOURCES', style: FinAITheme.label(10, FinAITheme.textMuted)),
          const Spacer(),
          Text(plan.ticker, style: GoogleFonts.syne(fontSize: 16, color: FinAITheme.textPrimary, fontWeight: FontWeight.w700)),
        ]),
        const SizedBox(height: 14),
        ...plan.sources.map((s) => _SourceRow(source: s)),
        const SizedBox(height: 16),
        Container(height: 0.5, color: FinAITheme.border),
        const SizedBox(height: 14),
        Text('EVIDENCE MAP', style: FinAITheme.label(10, FinAITheme.textMuted)),
        const SizedBox(height: 10),
        ...plan.evidence_links.map((e) => _EvidenceRow(evidence: e)),
      ]),
    );
  }
}

class _SourceRow extends StatelessWidget {
  final String source;
  const _SourceRow({required this.source});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: Row(children: [
      Container(width: 5, height: 5, decoration: BoxDecoration(color: FinAITheme.accentBlue, shape: BoxShape.circle)),
      const SizedBox(width: 10),
      Text(source, style: GoogleFonts.robotoMono(fontSize: 12, color: FinAITheme.textSecond)),
    ]),
  );
}

class _EvidenceRow extends StatelessWidget {
  final EvidenceLink evidence;
  const _EvidenceRow({required this.evidence});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Text(evidence.field_name.toUpperCase(), style: FinAITheme.label(9, FinAITheme.textMuted)),
          const SizedBox(width: 8),
          Text('${evidence.claimed_value}', style: GoogleFonts.robotoMono(fontSize: 12, color: FinAITheme.textPrimary, fontWeight: FontWeight.w700)),
        ]),
        Text('${evidence.scraper_index} · ${_fmt(evidence.timestamp)}',
          style: GoogleFonts.robotoMono(fontSize: 9, color: FinAITheme.textMuted)),
      ])),
      if (evidence.source_url != null)
        GestureDetector(
          onTap: () => launchUrl(Uri.parse(evidence.source_url!)),
          child: Icon(Icons.open_in_new_rounded, size: 14, color: FinAITheme.accentBlue),
        ),
    ]),
  );

  String _fmt(DateTime dt) => '${dt.hour.toString().padLeft(2,'0')}:${dt.minute.toString().padLeft(2,'0')}';
}
