// lib/features/research/ui/broker_connect_screen.dart

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../core/theme/app_theme.dart';

class BrokerConnectScreen extends StatefulWidget {
  const BrokerConnectScreen({super.key});
  @override
  State<BrokerConnectScreen> createState() => _BrokerConnectScreenState();
}

class _BrokerConnectScreenState extends State<BrokerConnectScreen> {
  final Map<String, bool> _connected = {
    'zerodha': false,
    'upstox': false,
    'coinswitch': false,
    'wazirx': false,
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: FinAITheme.bg,
      appBar: AppBar(
        backgroundColor: FinAITheme.bg,
        elevation: 0,
        leading: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Icon(Icons.arrow_back_ios_new_rounded, size: 18, color: FinAITheme.textSecond),
        ),
        title: Text('Connect Accounts', style: GoogleFonts.syne(fontSize: 18, color: FinAITheme.textPrimary, fontWeight: FontWeight.w700)),
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(height: 0.5, color: FinAITheme.border)),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const SizedBox(height: 8),
          Text('STOCK BROKERS', style: FinAITheme.label(10, FinAITheme.textMuted)),
          const SizedBox(height: 12),
          _BrokerCard(
            id: 'zerodha',
            name: 'Zerodha',
            subtitle: 'Kite Connect API',
            icon: Icons.show_chart,
            color: const Color(0xFF387ED1),
            connected: _connected['zerodha']!,
            onToggle: (v) => setState(() => _connected['zerodha'] = v),
          ),
          const SizedBox(height: 10),
          _BrokerCard(
            id: 'upstox',
            name: 'Upstox',
            subtitle: 'Upstox API v2',
            icon: Icons.trending_up,
            color: const Color(0xFF6C5CE7),
            connected: _connected['upstox']!,
            onToggle: (v) => setState(() => _connected['upstox'] = v),
          ),
          const SizedBox(height: 28),
          Text('CRYPTO EXCHANGES', style: FinAITheme.label(10, FinAITheme.textMuted)),
          const SizedBox(height: 12),
          _BrokerCard(
            id: 'coinswitch',
            name: 'CoinSwitch',
            subtitle: 'CoinSwitch Pro API',
            icon: Icons.currency_bitcoin,
            color: const Color(0xFFF7931A),
            connected: _connected['coinswitch']!,
            onToggle: (v) => setState(() => _connected['coinswitch'] = v),
          ),
          const SizedBox(height: 10),
          _BrokerCard(
            id: 'wazirx',
            name: 'WazirX',
            subtitle: 'WazirX Trade API',
            icon: Icons.bolt_rounded,
            color: const Color(0xFF00BCD4),
            connected: _connected['wazirx']!,
            onToggle: (v) => setState(() => _connected['wazirx'] = v),
          ),
          const SizedBox(height: 32),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: FinAITheme.accentBlue.withOpacity(0.06),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: FinAITheme.accentBlue.withOpacity(0.2)),
            ),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(Icons.lock_outline_rounded, size: 14, color: FinAITheme.accentLight),
              const SizedBox(width: 10),
              Expanded(child: Text(
                'Your API keys are stored encrypted on-device using AES-256. They are never transmitted to our servers.',
                style: GoogleFonts.robotoMono(fontSize: 10, color: FinAITheme.textSecond, height: 1.6),
              )),
            ]),
          ),
        ]),
      ),
    );
  }
}

class _BrokerCard extends StatelessWidget {
  final String id, name, subtitle;
  final IconData icon;
  final Color color;
  final bool connected;
  final ValueChanged<bool> onToggle;
  const _BrokerCard({required this.id, required this.name, required this.subtitle, required this.icon, required this.color, required this.connected, required this.onToggle});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: FinAITheme.bgSecondary,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: connected ? color.withOpacity(0.4) : FinAITheme.border),
      ),
      child: Row(children: [
        Container(
          width: 42, height: 42,
          decoration: BoxDecoration(color: color.withOpacity(0.12), borderRadius: BorderRadius.circular(10)),
          child: Icon(icon, color: color, size: 20),
        ),
        const SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(name, style: GoogleFonts.syne(fontSize: 15, color: FinAITheme.textPrimary, fontWeight: FontWeight.w600)),
          Text(subtitle, style: GoogleFonts.robotoMono(fontSize: 10, color: FinAITheme.textMuted)),
        ])),
        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Switch(
            value: connected,
            onChanged: onToggle,
            activeColor: FinAITheme.accentBlue,
            activeTrackColor: FinAITheme.accentBlue.withOpacity(0.3),
            inactiveTrackColor: FinAITheme.surface,
            inactiveThumbColor: FinAITheme.textMuted,
          ),
          Text(connected ? 'CONNECTED' : 'DISCONNECTED',
            style: GoogleFonts.robotoMono(fontSize: 8, color: connected ? FinAITheme.bullGreen : FinAITheme.textMuted, letterSpacing: 1)),
        ]),
      ]),
    );
  }
}
