// lib/features/research/ui/research_stepper.dart

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../core/models/research_models.dart';
import '../../../core/theme/app_theme.dart';

class ResearchStepperWidget extends StatelessWidget {
  final List<ResearchStep> steps;
  const ResearchStepperWidget({super.key, required this.steps});

  @override
  Widget build(BuildContext context) {
    final done = steps.where((s) => s.status == ResearchStepStatus.complete).length;
    final total = steps.length;
    final progress = done / total;
    final current = steps.where((s) => s.status == ResearchStepStatus.running).firstOrNull;

    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const SizedBox(height: 8),
        Row(children: [
          _PulsingDot(),
          const SizedBox(width: 10),
          Text('ANALYSING', style: FinAITheme.label(11, FinAITheme.accentLight)),
          const Spacer(),
          Text('$done/$total', style: GoogleFonts.robotoMono(fontSize: 12, color: FinAITheme.textSecond)),
        ]),
        const SizedBox(height: 14),
        ClipRRect(
          borderRadius: BorderRadius.circular(2),
          child: LinearProgressIndicator(
            value: progress,
            backgroundColor: FinAITheme.surface,
            valueColor: AlwaysStoppedAnimation<Color>(FinAITheme.accentBlue),
            minHeight: 2,
          ),
        ),
        if (current != null) ...[
          const SizedBox(height: 10),
          Text(current.label, style: GoogleFonts.robotoMono(fontSize: 11, color: FinAITheme.textSecond)),
        ],
        const SizedBox(height: 24),
        Expanded(
          child: ListView.separated(
            itemCount: steps.length,
            separatorBuilder: (_, __) => const SizedBox(height: 6),
            itemBuilder: (_, i) => _StepRow(step: steps[i]),
          ),
        ),
      ]),
    );
  }
}

class _StepRow extends StatelessWidget {
  final ResearchStep step;
  const _StepRow({required this.step});

  @override
  Widget build(BuildContext context) {
    final isRunning = step.status == ResearchStepStatus.running;
    final isDone = step.status == ResearchStepStatus.complete;
    final isFailed = step.status == ResearchStepStatus.failed;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
      decoration: BoxDecoration(
        color: isRunning ? FinAITheme.accentBlue.withOpacity(0.06) : FinAITheme.bgSecondary,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: isRunning ? FinAITheme.accentBlue.withOpacity(0.3) : FinAITheme.border),
      ),
      child: Row(children: [
        SizedBox(width: 18, height: 18, child: isRunning
          ? CircularProgressIndicator(strokeWidth: 1.5, color: FinAITheme.accentBlue)
          : Icon(
              isDone ? Icons.check_circle_rounded : isFailed ? Icons.cancel_rounded : Icons.radio_button_unchecked_rounded,
              size: 16,
              color: isDone ? FinAITheme.bullGreen : isFailed ? FinAITheme.bearRed : FinAITheme.textMuted,
            )),
        const SizedBox(width: 12),
        Expanded(child: Text(step.label, style: GoogleFonts.robotoMono(
          fontSize: 12,
          color: isRunning ? FinAITheme.textPrimary : isDone ? FinAITheme.textSecond : FinAITheme.textMuted,
          fontWeight: isRunning ? FontWeight.w600 : FontWeight.normal,
        ))),
        if (isDone) Text('done', style: GoogleFonts.robotoMono(fontSize: 9, color: FinAITheme.bullGreen.withOpacity(0.7), letterSpacing: 1)),
      ]),
    );
  }
}

class _PulsingDot extends StatefulWidget {
  @override
  State<_PulsingDot> createState() => _PulsingDotState();
}

class _PulsingDotState extends State<_PulsingDot> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800))..repeat(reverse: true);
    _anim = Tween<double>(begin: 0.3, end: 1.0).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => FadeTransition(
    opacity: _anim,
    child: Container(width: 7, height: 7,
      decoration: BoxDecoration(color: FinAITheme.accentBlue, shape: BoxShape.circle,
        boxShadow: [BoxShadow(color: FinAITheme.accentBlue.withOpacity(0.6), blurRadius: 8)])),
  );
}
