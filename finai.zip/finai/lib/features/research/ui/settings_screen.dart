// lib/features/research/ui/settings_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../../../core/theme/app_theme.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _storage = const FlutterSecureStorage();
  final _apiKeyCtrl = TextEditingController();
  bool _obscure = true;
  bool _saved = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final key = await _storage.read(key: 'gemini_api_key');
    if (key != null) setState(() => _apiKeyCtrl.text = key);
  }

  Future<void> _save() async {
    await _storage.write(key: 'gemini_api_key', value: _apiKeyCtrl.text.trim());
    setState(() => _saved = true);
    Future.delayed(const Duration(seconds: 2), () { if (mounted) setState(() => _saved = false); });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: FinAITheme.bg,
      appBar: AppBar(
        backgroundColor: FinAITheme.bg,
        elevation: 0,
        leading: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Icon(Icons.arrow_back_ios_new_rounded, size: 18, color: FinAITheme.textSecond),
        ),
        title: Text('Settings', style: GoogleFonts.syne(fontSize: 18, color: FinAITheme.textPrimary, fontWeight: FontWeight.w700)),
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(height: 0.5, color: FinAITheme.border)),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const SizedBox(height: 8),
          Text('AI ENGINE', style: FinAITheme.label(10, FinAITheme.textMuted)),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: FinAITheme.bgSecondary, borderRadius: BorderRadius.circular(12), border: Border.all(color: FinAITheme.border)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Container(
                  width: 36, height: 36,
                  decoration: BoxDecoration(color: FinAITheme.accentBlue.withOpacity(0.12), borderRadius: BorderRadius.circular(8)),
                  child: Icon(Icons.auto_awesome, size: 18, color: FinAITheme.accentBlue),
                ),
                const SizedBox(width: 12),
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Gemini API Key', style: GoogleFonts.syne(fontSize: 14, color: FinAITheme.textPrimary, fontWeight: FontWeight.w600)),
                  Text('Required for AI research analysis', style: GoogleFonts.robotoMono(fontSize: 10, color: FinAITheme.textMuted)),
                ]),
              ]),
              const SizedBox(height: 16),
              TextField(
                controller: _apiKeyCtrl,
                obscureText: _obscure,
                style: GoogleFonts.robotoMono(fontSize: 13, color: FinAITheme.textPrimary),
                decoration: InputDecoration(
                  hintText: 'AIza...',
                  hintStyle: GoogleFonts.robotoMono(fontSize: 13, color: FinAITheme.textMuted),
                  filled: true,
                  fillColor: FinAITheme.surface,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: BorderSide(color: FinAITheme.border)),
                  enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: BorderSide(color: FinAITheme.border)),
                  focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: BorderSide(color: FinAITheme.accentBlue)),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  suffixIcon: Row(mainAxisSize: MainAxisSize.min, children: [
                    GestureDetector(onTap: () { Clipboard.setData(ClipboardData(text: _apiKeyCtrl.text)); }, child: Padding(padding: const EdgeInsets.all(8), child: Icon(Icons.copy_outlined, size: 16, color: FinAITheme.textMuted))),
                    GestureDetector(onTap: () => setState(() => _obscure = !_obscure), child: Padding(padding: const EdgeInsets.all(8), child: Icon(_obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined, size: 16, color: FinAITheme.textMuted))),
                  ]),
                ),
              ),
              const SizedBox(height: 12),
              GestureDetector(
                onTap: _save,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 13),
                  decoration: BoxDecoration(
                    color: _saved ? FinAITheme.bullGreen : FinAITheme.accentBlue,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Center(child: Text(_saved ? '✓ SAVED' : 'SAVE KEY',
                    style: GoogleFonts.robotoMono(fontSize: 12, color: Colors.white, fontWeight: FontWeight.w700, letterSpacing: 1))),
                ),
              ),
              const SizedBox(height: 10),
              GestureDetector(
                onTap: () => launchUrlString('https://aistudio.google.com/app/apikey'),
                child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(Icons.open_in_new, size: 11, color: FinAITheme.accentLight),
                  const SizedBox(width: 4),
                  Text('Get a free API key at aistudio.google.com', style: GoogleFonts.robotoMono(fontSize: 10, color: FinAITheme.accentLight)),
                ]),
              ),
            ]),
          ),
        ]),
      ),
    );
  }
}

void launchUrlString(String url) {
  // url_launcher integration — implemented via broker_deep_link
}
