// lib/main.dart

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'core/theme/app_theme.dart';
import 'core/services/llm_service.dart';
import 'core/compliance/sebi_decision_log.dart';
import 'core/repositories/i_execution_repository.dart';
import 'features/research/bloc/research_bloc_fixed.dart';
import 'features/research/ui/dashboard_screen.dart';

class _StubRepository implements IExecutionRepository {
  final _ctrl = StreamController<OrderStatusEvent>.broadcast();
  @override bool get isLive => false;
  @override Stream<OrderStatusEvent> get orderStatusStream => _ctrl.stream;
  @override Future<bool> cancelOrder(String o) async => true;
  @override Future<Map<String, dynamic>?> getPosition(String t) async => null;
  @override Future<String> placeOrder({
    required plan,
    required quantity,
    required requireBiometricConfirm,
  }) async => 'PAPER-${DateTime.now().millisecondsSinceEpoch}';
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final sebiLog = SebiDecisionLog();
  // Skip DB init on web — sqflite not supported
  try { await sebiLog.initialize(); } catch (_) {}
  runApp(FinAIApp(sebiLog: sebiLog));
}

class FinAIApp extends StatelessWidget {
  final SebiDecisionLog sebiLog;
  const FinAIApp({super.key, required this.sebiLog});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => ResearchBloc(
        llmService: LlmService(),
        sebiLog: sebiLog,
        repository: _StubRepository(),
      ),
      child: MaterialApp(
        title: 'FinAI',
        debugShowCheckedModeBanner: false,
        theme: FinAITheme.theme(),
        home: const DashboardScreen(),
      ),
    );
  }
}