// lib/core/repositories/mock_paper_trader.dart

import 'dart:async';
import 'package:logger/logger.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:uuid/uuid.dart';
import '../models/research_models.dart';
import 'i_execution_repository.dart';

class MockPaperTrader implements IExecutionRepository {
  final _logger = Logger();
  final _orderController = StreamController<OrderStatusEvent>.broadcast();
  final _uuid = const Uuid();
  Database? _db;

  @override
  bool get isLive => false;

  Future<void> initialize() async {
    _db = await openDatabase(
      join(await getDatabasesPath(), 'paper_trades.db'),
      version: 1,
      onCreate: (db, v) async {
        await db.execute('''
          CREATE TABLE paper_orders (
            id          TEXT PRIMARY KEY,
            ticker      TEXT NOT NULL,
            entry       REAL NOT NULL,
            qty         INTEGER NOT NULL,
            status      TEXT NOT NULL,
            created_at  TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE paper_positions (
            ticker      TEXT PRIMARY KEY,
            qty         INTEGER NOT NULL,
            avg_price   REAL NOT NULL
          )
        ''');
      },
    );
  }

  @override
  Future<String> placeOrder({
    required ResearchPlan plan,
    required int quantity,
    required bool requireBiometricConfirm,
  }) async {
    _logger.i('[Paper] Order intent for ${plan.ticker} qty=$quantity');

    final orderId = _uuid.v4();
    final now = DateTime.now();

    await _db!.insert('paper_orders', {
      'id': orderId,
      'ticker': plan.ticker,
      'entry': plan.plan.entry,
      'qty': quantity,
      'status': 'open',
      'created_at': now.toIso8601String(),
    });

    Future.delayed(const Duration(milliseconds: 500), () async {
      await _db!.update(
        'paper_orders',
        {'status': 'complete'},
        where: 'id = ?',
        whereArgs: [orderId],
      );
      _orderController.add(OrderStatusEvent(
        order_id: orderId,
        status: 'complete',
        message: '[PAPER] Filled at ${plan.plan.entry}',
        timestamp: DateTime.now(),
      ));
      _logger.i('[Paper] Order $orderId filled (simulated)');
    });

    return orderId;
  }

  @override
  Future<Map<String, dynamic>?> getPosition(String ticker) async {
    final rows = await _db!.query(
      'paper_positions',
      where: 'ticker = ?',
      whereArgs: [ticker],
    );
    return rows.isEmpty ? null : rows.first;
  }

  @override
  Future<bool> cancelOrder(String orderId) async {
    final count = await _db!.update(
      'paper_orders',
      {'status': 'cancelled'},
      where: 'id = ? AND status = ?',
      whereArgs: [orderId, 'open'],
    );
    return count > 0;
  }

  @override
  Stream<OrderStatusEvent> get orderStatusStream => _orderController.stream;

  void dispose() {
    _orderController.close();
    _db?.close();
  }
}
