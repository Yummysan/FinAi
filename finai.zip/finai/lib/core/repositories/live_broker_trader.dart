// lib/core/repositories/live_broker_trader.dart

import 'dart:async';
import 'package:dio/dio.dart';
import 'package:local_auth/local_auth.dart';
import 'package:logger/logger.dart';
import '../models/research_models.dart';
import 'i_execution_repository.dart';

class LiveBrokerTrader implements IExecutionRepository {
  final String broker; // 'zerodha' | 'upstox'
  final Dio _dio;
  final LocalAuthentication _localAuth = LocalAuthentication();
  final _orderController = StreamController<OrderStatusEvent>.broadcast();
  final _logger = Logger();

  @override
  bool get isLive => true;

  LiveBrokerTrader({required this.broker})
      : _dio = Dio(BaseOptions(
          baseUrl: broker == 'zerodha'
              ? 'https://api.kite.trade'
              : 'https://api.upstox.com/v2',
          headers: {'X-Kite-Version': '3'},
        ));

  @override
  Future<String> placeOrder({
    required ResearchPlan plan,
    required int quantity,
    required bool requireBiometricConfirm,
  }) async {
    if (requireBiometricConfirm) {
      final didAuth = await _localAuth.authenticate(
        localizedReason:
            'Confirm trade: ${plan.ticker} × $quantity @ ₹${plan.plan.entry.toStringAsFixed(2)}',
        options: const AuthenticationOptions(
          biometricOnly: false,
          stickyAuth: true,
        ),
      );
      if (!didAuth) {
        throw Exception('SEBI_BIOMETRIC_BLOCKED: User did not confirm trade');
      }
    }

    try {
      final resp = await _dio.post('/orders/regular', data: {
        'tradingsymbol': plan.ticker,
        'exchange': 'NSE',
        'transaction_type': 'BUY',
        'order_type': 'LIMIT',
        'quantity': quantity,
        'price': plan.plan.entry,
        'product': 'CNC',
      });

      final orderId = resp.data['data']['order_id'] as String;
      _logger.i('[Live-$broker] Order placed: $orderId');
      return orderId;
    } on DioException catch (e) {
      _logger.e('[Live-$broker] Order failed: ${e.message}');
      rethrow;
    }
  }

  @override
  Future<Map<String, dynamic>?> getPosition(String ticker) async {
    final resp = await _dio.get('/portfolio/positions');
    final positions = resp.data['data']['net'] as List;
    return positions.cast<Map<String, dynamic>>().firstWhere(
          (p) => p['tradingsymbol'] == ticker,
          orElse: () => {},
        );
  }

  @override
  Future<bool> cancelOrder(String orderId) async {
    try {
      await _dio.delete('/orders/regular/$orderId');
      return true;
    } catch (_) {
      return false;
    }
  }

  @override
  Stream<OrderStatusEvent> get orderStatusStream => _orderController.stream;

  void dispose() {
    _orderController.close();
  }
}
