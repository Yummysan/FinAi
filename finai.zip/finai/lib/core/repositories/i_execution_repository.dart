// lib/core/repositories/i_execution_repository.dart

import '../models/research_models.dart';

class OrderStatusEvent {
  final String order_id;
  final String status; // 'open' | 'complete' | 'cancelled' | 'rejected'
  final String? message;
  final DateTime timestamp;

  const OrderStatusEvent({
    required this.order_id,
    required this.status,
    this.message,
    required this.timestamp,
  });
}

abstract class IExecutionRepository {
  Future<String> placeOrder({
    required ResearchPlan plan,
    required int quantity,
    required bool requireBiometricConfirm,
  });

  Future<Map<String, dynamic>?> getPosition(String ticker);

  Future<bool> cancelOrder(String orderId);

  Stream<OrderStatusEvent> get orderStatusStream;

  bool get isLive;
}
