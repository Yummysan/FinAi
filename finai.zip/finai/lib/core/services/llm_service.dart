// lib/core/services/llm_service.dart
// AI Quant Spec — Chain-of-Thought, Evidence Mapping, Judge Layer

import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:logger/logger.dart';
import '../models/research_models.dart';

/// Thrown when the Judge Layer fails validation (delta > 0.01%)
class HallucinationDetected implements Exception {
  final String field;
  final double llm_value;
  final double scraped_value;
  final double delta_pct;
  HallucinationDetected(this.field, this.llm_value, this.scraped_value, this.delta_pct);

  @override
  String toString() =>
      'HallucinationDetected: $field — LLM=$llm_value, Scraped=$scraped_value, Δ=${delta_pct.toStringAsFixed(4)}%';
}

class LlmService {
  final Dio _dio;
  final _logger = Logger();

  // Max retries when Judge fails
  static const int _maxRetries = 3;

  LlmService({Dio? dio})
      : _dio = dio ??
            Dio(BaseOptions(
              baseUrl: 'https://generativelanguage.googleapis.com/v1beta',
              connectTimeout: const Duration(seconds: 30),
              receiveTimeout: const Duration(seconds: 60),
            ));

  // ── Main entry point ──────────────────────────────────────────────────────
  /// Calls LLM, validates output with Judge, retries on failure.
  /// Returns validated ResearchPlan + the raw prompt used (for SEBI log).
  Future<({ResearchPlan plan, String prompt_used})> generateResearchPlan({
    required String ticker,
    required String asset_type,
    required List<RawScraperData> scraped_data,
    String? api_key,
  }) async {
    final prompt = _buildPrompt(ticker, asset_type, scraped_data);
    ResearchPlan? plan;
    Exception? lastError;

    for (int attempt = 1; attempt <= _maxRetries; attempt++) {
      _logger.i('[LLM] Attempt $attempt/$_maxRetries for $ticker');
      try {
        final raw_json = await _callGemini(prompt, api_key: api_key);
        plan = _parseAndValidate(raw_json);

        // ── Judge Layer ───────────────────────────────────────────────────
        _judgeOutput(plan, scraped_data);

        _logger.i('[LLM] Judge PASSED for $ticker on attempt $attempt');
        return (plan: plan, prompt_used: prompt);
      } on HallucinationDetected catch (e) {
        lastError = e;
        _logger.w('[LLM] Judge FAILED attempt $attempt: $e');
        // Add failure context to next prompt
      } catch (e) {
        lastError = Exception(e.toString());
        _logger.e('[LLM] LLM call failed attempt $attempt: $e');
      }
    }

    throw lastError!;
  }

  // ── Prompt Builder (Chain-of-Thought + Schema enforcement) ────────────────
  String _buildPrompt(
    String ticker,
    String asset_type,
    List<RawScraperData> scraped_data,
  ) {
    final data_block = scraped_data
        .map((s) =>
            '  [${s.scraper_id} @ ${s.scraped_at.toIso8601String()}]: ${jsonEncode(s.raw_fields)}')
        .join('\n');

    return '''
You are a quantitative research assistant generating a trade research plan.

## CRITICAL RULES
1. First, reason through your analysis in a <thinking> block (Chain-of-Thought). 
   Include your math, assumptions, and data checks.
2. After <thinking>, output ONLY a valid JSON object matching the schema below.
3. Every numeric field in "plan" and every figure in "sources" MUST have a matching 
   entry in "evidence_links" citing the exact scraper_id and timestamp.
4. Do NOT hallucinate data. Only cite figures present in the raw data below.
5. Keep "llm_cot_monologue" to a concise summary of your reasoning (≤300 words).

## RAW MARKET DATA (source of truth — do not invent numbers beyond this)
Ticker: $ticker
Asset Type: $asset_type
$data_block

## OUTPUT JSON SCHEMA (output ONLY this — no markdown fences)
{
  "ticker": "$ticker",
  "asset_type": "$asset_type",
  "plan": {
    "split": <float 0.0–1.0 — fraction of capital>,
    "entry": <float — entry price in INR>,
    "stop_loss": <float — stop loss price in INR>,
    "target": <float or null>
  },
  "confidence": <float 0.0–1.0>,
  "sources": ["<scraper_id>_<HH:MM>", ...],
  "evidence_links": [
    {
      "field_name": "<field e.g. entry>",
      "claimed_value": <value>,
      "scraper_index": "<scraper_id>",
      "timestamp": "<ISO8601>",
      "source_url": "<url or null>"
    }
  ],
  "llm_cot_monologue": "<your condensed reasoning>",
  "generated_at": "<ISO8601 now>"
}
''';
  }

  // ── Gemini API Call ───────────────────────────────────────────────────────
  Future<Map<String, dynamic>> _callGemini(
    String prompt, {
    String? api_key,
  }) async {
    final resp = await _dio.post(
      '/models/gemini-2.0-flash:generateContent',
      queryParameters: {'key': api_key ?? ''},
      data: {
        'contents': [
          {
            'role': 'user',
            'parts': [
              {'text': prompt}
            ]
          }
        ],
        'generationConfig': {
          'temperature': 0.1, // Low temp for deterministic financial output
          'topP': 0.8,
          'maxOutputTokens': 2048,
        },
      },
    );

    final text = resp.data['candidates'][0]['content']['parts'][0]['text'] as String;
    // Strip any accidental markdown fences
    final cleaned = text
        .replaceAll(RegExp(r'```json\s*'), '')
        .replaceAll(RegExp(r'```\s*'), '')
        .trim();

    return jsonDecode(cleaned) as Map<String, dynamic>;
  }

  // ── Parse + Validate Schema ───────────────────────────────────────────────
  ResearchPlan _parseAndValidate(Map<String, dynamic> json) {
    // Will throw if schema is wrong — triggers a retry
    return ResearchPlan.fromJson(json);
  }

  // ── Judge Layer ───────────────────────────────────────────────────────────
  // Cross-references LLM output against raw scraper data.
  // If any numeric field differs by > 0.01%, it throws HallucinationDetected.
  void _judgeOutput(ResearchPlan plan, List<RawScraperData> scraped_data) {
    const double threshold = 0.0001; // 0.01%

    // Build a flat lookup: {scraper_id: {field: value}}
    final Map<String, Map<String, dynamic>> scraper_lookup = {
      for (final s in scraped_data) s.scraper_id: s.raw_fields,
    };

    for (final evidence in plan.evidence_links) {
      final scraper_fields = scraper_lookup[evidence.scraper_index];
      if (scraper_fields == null) {
        _logger.w('[Judge] Unknown scraper_index: ${evidence.scraper_index}');
        continue;
      }

      final scraped_value = scraper_fields[evidence.field_name];
      if (scraped_value == null) continue; // field not in raw data, skip

      final llm_val = (evidence.claimed_value as num).toDouble();
      final raw_val = (scraped_value as num).toDouble();

      if (raw_val == 0) continue;
      final delta = ((llm_val - raw_val) / raw_val).abs();

      if (delta > threshold) {
        throw HallucinationDetected(
          evidence.field_name,
          llm_val,
          raw_val,
          delta * 100,
        );
      }
    }
  }
}
