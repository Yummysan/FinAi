// lib/core/services/tax_engine.dart
// 2026 Indian Tax Engine — LaTeX-verified formulas from Compliance Spec

/// Asset class determines which tax regime applies.
enum AssetClass { crypto, equityIntraday, equityShortTerm, equityLongTerm, usEquity }

/// Output of a tax calculation.
class TaxCalculation {
  final AssetClass asset_class;
  final double gross_gain;
  final double tax_amount;
  final double tds_amount;
  final double stt_amount;
  final double gst_on_brokerage;
  final double lrs_tcs_amount; // LRS TCS for US stocks
  final double net_profit;
  final String formula_trace; // Human-readable formula for audit log

  const TaxCalculation({
    required this.asset_class,
    required this.gross_gain,
    required this.tax_amount,
    required this.tds_amount,
    required this.stt_amount,
    required this.gst_on_brokerage,
    required this.lrs_tcs_amount,
    required this.net_profit,
    required this.formula_trace,
  });
}

class IndianTaxEngine {
  // ── Crypto (VDA) ─────────────────────────────────────────────────────────
  // Flat 30% on gains, 1% TDS on total transaction value.
  // Formula: Profit_net = (Gains × 0.70) − (Value_total × 0.01)
  static TaxCalculation calculateCrypto({
    required double gains,
    required double total_transaction_value,
  }) {
    const double flatTaxRate = 0.30;
    const double tdsRate = 0.01;

    final tax = gains * flatTaxRate;
    final tds = total_transaction_value * tdsRate;
    final net = (gains * (1 - flatTaxRate)) - tds;

    return TaxCalculation(
      asset_class: AssetClass.crypto,
      gross_gain: gains,
      tax_amount: tax,
      tds_amount: tds,
      stt_amount: 0.0,
      gst_on_brokerage: 0.0,
      lrs_tcs_amount: 0.0,
      net_profit: net,
      formula_trace:
          'VDA: Profit_net = (${_fmt(gains)} × 0.70) − (${_fmt(total_transaction_value)} × 0.01) = ${_fmt(net)}',
    );
  }

  // ── Equity (Domestic) ────────────────────────────────────────────────────
  // STT: 0.1% on sell-side for delivery. 0.025% for intraday sell-side.
  // GST: 18% on brokerage (assume ₹20 flat brokerage → ₹3.6 GST per leg).
  // STCG: 20% if held < 1 year. LTCG: 12.5% above ₹1.25L exemption (FY26).
  static TaxCalculation calculateEquity({
    required double sell_value,
    required double gains,
    required bool is_intraday,
    required bool is_long_term,
    required double brokerage,
  }) {
    // STT
    final double stt_rate = is_intraday ? 0.00025 : 0.001;
    final double stt = sell_value * stt_rate;

    // GST on brokerage (18%)
    final double gst = brokerage * 0.18;

    // Tax on gains
    double taxRate;
    AssetClass assetClass;
    if (is_intraday) {
      taxRate = 0.30; // Treated as speculative business income (slab)
      assetClass = AssetClass.equityIntraday;
    } else if (is_long_term) {
      taxRate = 0.125; // 12.5% LTCG (FY2026)
      assetClass = AssetClass.equityLongTerm;
    } else {
      taxRate = 0.20; // 20% STCG (FY2026)
      assetClass = AssetClass.equityShortTerm;
    }

    final double tax = gains > 0 ? gains * taxRate : 0.0;
    final double net = gains - tax - stt - gst;

    return TaxCalculation(
      asset_class: assetClass,
      gross_gain: gains,
      tax_amount: tax,
      tds_amount: 0.0,
      stt_amount: stt,
      gst_on_brokerage: gst,
      lrs_tcs_amount: 0.0,
      net_profit: net,
      formula_trace:
          'EQ(${is_intraday ? "INTRA" : is_long_term ? "LTCG" : "STCG"}): '
          'Net = ${_fmt(gains)} − Tax(${(taxRate * 100).toStringAsFixed(1)}%)=${_fmt(tax)} '
          '− STT=${_fmt(stt)} − GST=${_fmt(gst)} = ${_fmt(net)}',
    );
  }

  // ── US Equity via LRS ────────────────────────────────────────────────────
  // LRS TCS: 20% on remittance above ₹7L per FY (FY2026 threshold).
  // Capital gains taxed as per DTAA (India-US treaty): 20% LTCG / slab STCG.
  static TaxCalculation calculateUSEquity({
    required double gains,
    required double remittance_amount,
    required bool is_long_term,
    double lrs_exemption = 700000.0, // ₹7 lakh threshold
  }) {
    const double lrsTCSRate = 0.20;
    final double taxable_remittance =
        (remittance_amount - lrs_exemption).clamp(0.0, double.infinity);
    final double lrs_tcs = taxable_remittance * lrsTCSRate;

    final double taxRate = is_long_term ? 0.20 : 0.30;
    final double tax = gains > 0 ? gains * taxRate : 0.0;
    final double net = gains - tax - lrs_tcs;

    return TaxCalculation(
      asset_class: AssetClass.usEquity,
      gross_gain: gains,
      tax_amount: tax,
      tds_amount: 0.0,
      stt_amount: 0.0,
      gst_on_brokerage: 0.0,
      lrs_tcs_amount: lrs_tcs,
      net_profit: net,
      formula_trace:
          'US-LRS: Net = ${_fmt(gains)} − Tax(${(taxRate * 100).toInt()}%)=${_fmt(tax)} '
          '− LRS_TCS(20% on remittance >₹7L)=${_fmt(lrs_tcs)} = ${_fmt(net)}',
    );
  }

  static String _fmt(double v) =>
      '₹${v.abs().toStringAsFixed(2)}${v < 0 ? " (loss)" : ""}';
}
