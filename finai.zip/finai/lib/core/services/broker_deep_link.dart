// lib/core/services/broker_deep_link.dart
// Deep Link Factory — Zerodha (kite://) and Upstox (OAuth intent-based)

import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';
import 'package:logger/logger.dart';
import '../models/research_models.dart';

enum BrokerTarget { zerodha, upstox }

class BrokerDeepLink {
  static final _logger = Logger();

  /// Constructs and launches a pre-filled basket order URI.
  static Future<bool> launchOrder({
    required ResearchPlan plan,
    required int quantity,
    required BrokerTarget broker,
  }) async {
    final uri = broker == BrokerTarget.zerodha
        ? _buildZerodhaUri(plan, quantity)
        : await _buildUpstoxUri(plan, quantity);

    _logger.i('[DeepLink] Launching: $uri');

    if (!await canLaunchUrl(Uri.parse(uri))) {
      _logger.w('[DeepLink] App not installed for $broker');
      return false;
    }

    return launchUrl(
      Uri.parse(uri),
      mode: LaunchMode.externalApplication,
    );
  }

  // ── Zerodha: kite://basket?data=[...] ────────────────────────────────────
  // Kite basket order URI spec (Zerodha developer docs)
  static String _buildZerodhaUri(ResearchPlan plan, int quantity) {
    final basket = [
      {
        'variety': 'regular',
        'tradingsymbol': plan.ticker,
        'exchange': _exchange(plan.asset_type),
        'transaction_type': 'BUY',
        'order_type': 'LIMIT',
        'quantity': quantity,
        'price': plan.plan.entry,
        'product': 'CNC',
      }
    ];

    // Zerodha expects base64url-encoded JSON
    final data = base64Url.encode(utf8.encode(jsonEncode(basket)));
    return 'kite://basket?data=$data';
  }

  // ── Upstox: OAuth flow → intent-based placement ───────────────────────────
  // Upstox Trade API v2 uses a web-based OAuth consent + redirect
  static Future<String> _buildUpstoxUri(
    ResearchPlan plan,
    int quantity,
  ) async {
    // Construct the trade URL — user authenticates via OAuth in browser,
    // then gets redirected back to the app via deep link callback.
    final params = {
      'instrument_key': _upstoxKey(plan.ticker, plan.asset_type),
      'quantity': quantity.toString(),
      'price': plan.plan.entry.toStringAsFixed(2),
      'order_type': 'LIMIT',
      'transaction_type': 'BUY',
      'product': 'D', // Delivery
    };

    final query = params.entries
        .map((e) => '${e.key}=${Uri.encodeComponent(e.value)}')
        .join('&');

    // Upstox Trade API redirect URI
    return 'https://api.upstox.com/v2/order/place?$query';
  }

  static String _exchange(String asset_type) {
    return switch (asset_type) {
      'crypto' => 'CDS',
      'us_equity' => 'BSE', // via NSE IFSC or BSE depending on broker
      _ => 'NSE',
    };
  }

  static String _upstoxKey(String ticker, String asset_type) {
    // Upstox instrument keys: NSE_EQ|INFY, NSE_CRYPTO|BTC, etc.
    final exchange = switch (asset_type) {
      'crypto' => 'NSE_CRYPTO',
      'us_equity' => 'NSE_IFSC',
      _ => 'NSE_EQ',
    };
    return '$exchange|$ticker';
  }
}
