// lib/core/theme/app_theme.dart

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class FinAITheme {
  // ── Palette ────────────────────────────────────────────────────────────────
  static const Color bg          = Color(0xFF070D1A);   // near-black navy
  static const Color bgSecondary = Color(0xFF0C1526);   // card bg
  static const Color surface     = Color(0xFF111E33);   // elevated surface
  static const Color border      = Color(0xFF1A2E4A);   // subtle border
  static const Color borderLight = Color(0xFF1F3A5F);   // hover/active border

  static const Color accentBlue  = Color(0xFF2979FF);   // primary CTA
  static const Color accentLight = Color(0xFF64B5F6);   // secondary / labels
  static const Color accentGlow  = Color(0x332979FF);   // glow shadow

  static const Color bullGreen   = Color(0xFF00C853);
  static const Color bearRed     = Color(0xFFFF3D57);
  static const Color warningAmber= Color(0xFFFFAB00);

  static const Color textPrimary = Color(0xFFE8F0FE);
  static const Color textSecond  = Color(0xFF8EAAC8);
  static const Color textMuted   = Color(0xFF3D5A7A);

  // ── Typography ─────────────────────────────────────────────────────────────
  static TextStyle mono(double size, Color color, {FontWeight weight = FontWeight.normal}) =>
      GoogleFonts.robotoMono(fontSize: size, color: color, fontWeight: weight);

  static TextStyle display(double size, Color color, {FontWeight weight = FontWeight.w700}) =>
      GoogleFonts.syne(fontSize: size, color: color, fontWeight: weight);

  static TextStyle label(double size, Color color) =>
      GoogleFonts.robotoMono(fontSize: size, color: color, letterSpacing: 1.5);

  // ── Decorations ────────────────────────────────────────────────────────────
  static BoxDecoration card({Color? borderColor, bool glow = false}) => BoxDecoration(
    color: bgSecondary,
    borderRadius: BorderRadius.circular(12),
    border: Border.all(color: borderColor ?? border),
    boxShadow: glow ? [BoxShadow(color: accentGlow, blurRadius: 24, offset: const Offset(0, 4))] : null,
  );

  static BoxDecoration glowButton() => BoxDecoration(
    color: accentBlue,
    borderRadius: BorderRadius.circular(10),
    boxShadow: [BoxShadow(color: accentBlue.withOpacity(0.4), blurRadius: 20, offset: const Offset(0, 6))],
  );

  // ── ThemeData ──────────────────────────────────────────────────────────────
  static ThemeData theme() => ThemeData(
    brightness: Brightness.dark,
    scaffoldBackgroundColor: bg,
    colorScheme: const ColorScheme.dark(
      primary: accentBlue,
      surface: bgSecondary,
    ),
    textTheme: GoogleFonts.interTextTheme(ThemeData.dark().textTheme),
  );
}
