// lib/core/compliance/sebi_decision_log.dart
// SEBI 2026 Accountability Framework — Encrypted AI Decision Log
// Stores: prompt + raw_data + LLM output for 7-year retention.

import 'dart:convert';
import 'package:encrypt/encrypt.dart' as enc;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:logger/logger.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/research_models.dart';

class SebiDecisionLog {
  static const String _dbName = 'sebi_audit_log.db';
  static const String _tableName = 'ai_decisions';
  static const int _retentionYears = 7;

  final _storage = const FlutterSecureStorage();
  final _logger = Logger();
  Database? _db;

  // Singleton
  static final SebiDecisionLog _instance = SebiDecisionLog._internal();
  factory SebiDecisionLog() => _instance;
  SebiDecisionLog._internal();

  // ── Init ──────────────────────────────────────────────────────────────────
  Future<void> initialize() async {
    _db = await openDatabase(
      join(await getDatabasesPath(), _dbName),
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE $_tableName (
            id          TEXT    PRIMARY KEY,
            ticker      TEXT    NOT NULL,
            asset_type  TEXT    NOT NULL,
            prompt_enc  TEXT    NOT NULL,   -- AES-256 encrypted
            raw_data_enc TEXT   NOT NULL,   -- AES-256 encrypted
            llm_output_enc TEXT NOT NULL,   -- AES-256 encrypted
            confidence  REAL    NOT NULL,
            sources_json TEXT   NOT NULL,
            tax_formula TEXT,
            created_at  TEXT    NOT NULL,
            expires_at  TEXT    NOT NULL    -- created_at + 7 years
          )
        ''');
        await db.execute(
          'CREATE INDEX idx_ticker ON $_tableName(ticker)',
        );
        await db.execute(
          'CREATE INDEX idx_created ON $_tableName(created_at)',
        );
      },
    );
    _logger.i('[SEBI Log] Database initialized: $_dbName');
  }

  // ── Write ─────────────────────────────────────────────────────────────────
  Future<String> logDecision({
    required String id,
    required String prompt,
    required Map<String, dynamic> raw_scraper_data,
    required ResearchPlan llm_output,
    String? tax_formula_trace,
  }) async {
    assert(_db != null, 'Call initialize() first');

    final key = await _getOrCreateKey();
    final encrypter = enc.Encrypter(enc.AES(key, mode: enc.AESMode.gcm));

    final promptEnc = _encrypt(encrypter, prompt);
    final rawEnc = _encrypt(encrypter, jsonEncode(raw_scraper_data));
    final outputEnc = _encrypt(encrypter, jsonEncode(llm_output.toJson()));

    final now = DateTime.now().toUtc();
    final expires = now.add(const Duration(days: 365 * _retentionYears));

    await _db!.insert(
      _tableName,
      {
        'id': id,
        'ticker': llm_output.ticker,
        'asset_type': llm_output.asset_type,
        'prompt_enc': promptEnc,
        'raw_data_enc': rawEnc,
        'llm_output_enc': outputEnc,
        'confidence': llm_output.confidence,
        'sources_json': jsonEncode(llm_output.sources),
        'tax_formula': tax_formula_trace,
        'created_at': now.toIso8601String(),
        'expires_at': expires.toIso8601String(),
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );

    _logger.i('[SEBI Log] Logged decision id=$id ticker=${llm_output.ticker}');
    return id;
  }

  // ── Read (for audit export) ───────────────────────────────────────────────
  Future<Map<String, dynamic>?> readDecision(String id) async {
    assert(_db != null, 'Call initialize() first');
    final key = await _getOrCreateKey();
    final encrypter = enc.Encrypter(enc.AES(key, mode: enc.AESMode.gcm));

    final rows = await _db!.query(
      _tableName,
      where: 'id = ?',
      whereArgs: [id],
    );
    if (rows.isEmpty) return null;
    final row = rows.first;

    return {
      'id': row['id'],
      'ticker': row['ticker'],
      'asset_type': row['asset_type'],
      'prompt': _decrypt(encrypter, row['prompt_enc'] as String),
      'raw_scraper_data':
          jsonDecode(_decrypt(encrypter, row['raw_data_enc'] as String)),
      'llm_output':
          jsonDecode(_decrypt(encrypter, row['llm_output_enc'] as String)),
      'confidence': row['confidence'],
      'sources': jsonDecode(row['sources_json'] as String),
      'tax_formula': row['tax_formula'],
      'created_at': row['created_at'],
      'expires_at': row['expires_at'],
    };
  }

  // ── Purge expired records (run on app start) ──────────────────────────────
  Future<int> purgeExpired() async {
    assert(_db != null, 'Call initialize() first');
    final now = DateTime.now().toUtc().toIso8601String();
    final deleted = await _db!.delete(
      _tableName,
      where: 'expires_at < ?',
      whereArgs: [now],
    );
    if (deleted > 0) {
      _logger.w('[SEBI Log] Purged $deleted expired records (>7yr)');
    }
    return deleted;
  }

  // ── Crypto helpers ────────────────────────────────────────────────────────
  Future<enc.Key> _getOrCreateKey() async {
    const storageKey = 'sebi_aes_key_v1';
    String? keyB64 = await _storage.read(key: storageKey);
    if (keyB64 == null) {
      final k = enc.Key.fromSecureRandom(32);
      await _storage.write(key: storageKey, value: k.base64);
      return k;
    }
    return enc.Key.fromBase64(keyB64);
  }

  String _encrypt(enc.Encrypter encrypter, String plaintext) {
    final iv = enc.IV.fromSecureRandom(12); // GCM: 96-bit IV
    final encrypted = encrypter.encrypt(plaintext, iv: iv);
    // Store as "iv:ciphertext" (both base64)
    return '${iv.base64}:${encrypted.base64}';
  }

  String _decrypt(enc.Encrypter encrypter, String stored) {
    final parts = stored.split(':');
    final iv = enc.IV.fromBase64(parts[0]);
    final encrypted = enc.Encrypted.fromBase64(parts[1]);
    return encrypter.decrypt(encrypted, iv: iv);
  }
}
