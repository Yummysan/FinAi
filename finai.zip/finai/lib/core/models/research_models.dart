// lib/core/models/research_models.dart
// Schema-first typed models (Spec: AI Quant — Schema-First Generation)

import 'package:equatable/equatable.dart';

/// Strictly typed JSON schema for LLM output validation.
/// Every field that the LLM populates must have a matching evidence_link.
class ResearchPlan extends Equatable {
  final String ticker;
  final String asset_type; // 'equity' | 'crypto' | 'us_equity'
  final TradePlan plan;
  final double confidence; // 0.0 – 1.0
  final List<String> sources; // e.g. ["NSE_API_10:04", "CoinSwitch_10:05"]
  final List<EvidenceLink> evidence_links;
  final String? llm_cot_monologue; // Chain-of-Thought reasoning (internal)
  final DateTime generated_at;

  const ResearchPlan({
    required this.ticker,
    required this.asset_type,
    required this.plan,
    required this.confidence,
    required this.sources,
    required this.evidence_links,
    this.llm_cot_monologue,
    required this.generated_at,
  });

  factory ResearchPlan.fromJson(Map<String, dynamic> json) => ResearchPlan(
        ticker: json['ticker'] as String,
        asset_type: json['asset_type'] as String,
        plan: TradePlan.fromJson(json['plan'] as Map<String, dynamic>),
        confidence: (json['confidence'] as num).toDouble(),
        sources: List<String>.from(json['sources'] as List),
        evidence_links: (json['evidence_links'] as List)
            .map((e) => EvidenceLink.fromJson(e as Map<String, dynamic>))
            .toList(),
        llm_cot_monologue: json['llm_cot_monologue'] as String?,
        generated_at: DateTime.parse(json['generated_at'] as String),
      );

  Map<String, dynamic> toJson() => {
        'ticker': ticker,
        'asset_type': asset_type,
        'plan': plan.toJson(),
        'confidence': confidence,
        'sources': sources,
        'evidence_links': evidence_links.map((e) => e.toJson()).toList(),
        'llm_cot_monologue': llm_cot_monologue,
        'generated_at': generated_at.toIso8601String(),
      };

  @override
  List<Object?> get props => [ticker, generated_at];
}

class TradePlan extends Equatable {
  final double split; // Position size as fraction of capital (0.0–1.0)
  final double entry;
  final double stop_loss;
  final double? target;

  const TradePlan({
    required this.split,
    required this.entry,
    required this.stop_loss,
    this.target,
  });

  factory TradePlan.fromJson(Map<String, dynamic> json) => TradePlan(
        split: (json['split'] as num).toDouble(),
        entry: (json['entry'] as num).toDouble(),
        stop_loss: (json['stop_loss'] as num).toDouble(),
        target: json['target'] != null ? (json['target'] as num).toDouble() : null,
      );

  Map<String, dynamic> toJson() => {
        'split': split,
        'entry': entry,
        'stop_loss': stop_loss,
        'target': target,
      };

  @override
  List<Object?> get props => [split, entry, stop_loss, target];
}

class EvidenceLink extends Equatable {
  final String field_name; // e.g. "pe_ratio"
  final dynamic claimed_value;
  final String scraper_index; // e.g. "NSE_Scraper_3"
  final DateTime timestamp;
  final String? source_url;

  const EvidenceLink({
    required this.field_name,
    required this.claimed_value,
    required this.scraper_index,
    required this.timestamp,
    this.source_url,
  });

  factory EvidenceLink.fromJson(Map<String, dynamic> json) => EvidenceLink(
        field_name: json['field_name'] as String,
        claimed_value: json['claimed_value'],
        scraper_index: json['scraper_index'] as String,
        timestamp: DateTime.parse(json['timestamp'] as String),
        source_url: json['source_url'] as String?,
      );

  Map<String, dynamic> toJson() => {
        'field_name': field_name,
        'claimed_value': claimed_value,
        'scraper_index': scraper_index,
        'timestamp': timestamp.toIso8601String(),
        'source_url': source_url,
      };

  @override
  List<Object?> get props => [field_name, scraper_index, timestamp];
}

/// Represents one step in the async research pipeline
enum ResearchStepStatus { pending, running, complete, failed }

class ResearchStep extends Equatable {
  final String id; // e.g. "Scraper_1"
  final String label; // e.g. "Fetching NSE live feed"
  final ResearchStepStatus status;
  final String? detail;

  const ResearchStep({
    required this.id,
    required this.label,
    required this.status,
    this.detail,
  });

  ResearchStep copyWith({
    ResearchStepStatus? status,
    String? detail,
  }) =>
      ResearchStep(
        id: id,
        label: label,
        status: status ?? this.status,
        detail: detail ?? this.detail,
      );

  @override
  List<Object?> get props => [id, status];
}

/// The scraped raw market data — used by the Judge Layer to cross-validate LLM output
class RawScraperData extends Equatable {
  final String scraper_id;
  final String ticker;
  final Map<String, dynamic> raw_fields; // e.g. {ltp: 320100, pe: 24.9}
  final DateTime scraped_at;

  const RawScraperData({
    required this.scraper_id,
    required this.ticker,
    required this.raw_fields,
    required this.scraped_at,
  });

  @override
  List<Object?> get props => [scraper_id, ticker, scraped_at];
}
